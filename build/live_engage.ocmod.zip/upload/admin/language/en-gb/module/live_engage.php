<?php

// Heading
$_['heading_title']    = '<strong>LivePerson LiveEngage Widget';

$_['heading_title_m']    				= 'LivePerson LiveEngage Widget';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified LivePerson LiveEngage Widget module!';
$_['text_off']         = 'Off';
$_['text_on']          = 'On';
$_['text_edit']        = 'Edit LivePerson LiveEngage Widget';


// Admin form
$_['form_live_engage_id'] = 'LivePerson Account Number';
$_['form_enabled']       = 'Enable';


// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the LivePerson LiveEngage module!';
$_['error_live_engage_id'] = 'LivePerson account number is Required!';
